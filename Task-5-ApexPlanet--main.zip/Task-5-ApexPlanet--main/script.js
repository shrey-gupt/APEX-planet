// Helper function to format prices in Indian Rupees
function formatPrice(price) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0, // Remove decimal places
    }).format(price);
}


// Sample Product Data
const products = [
    { id: 1, name: "Laptop", category: "electronics", price: 99999, image: "assets/img/laptop.jpg" },
    { id: 2, name: "T-Shirt", category: "fashion", price: 200, image: "assets/img/tshirt.jpg" },
    { id: 3, name: "Blender", category: "home", price: 3000, image: "assets/img/blender.jpeg" },
    { id: 4, name: "Smartphone", category: "electronics", price: 17000, image: "assets/img/smartphone.avif" },
    { id: 5, name: "Jeans", category: "fashion", price: 1500, image: "assets/img/jeans.jpeg" },
    { id: 6, name: "Coffee Maker", category: "home", price: 5000, image: "assets/img/coffeeMker.jpeg" },
    { id: 7, name: "Headphones", category: "electronics", price: 4500, image: "assets/img/headphones.jpeg" },
    { id: 8, name: "Dress", category: "fashion", price: 1600, image: "assets/img/dress.jpeg" },
    { id: 9, name: "Lamp", category: "home", price: 300, image: "assets/img/lamp.jpeg" }
];

// Cart State
let cart = [];

// DOM Elements
const productList = document.getElementById("product-list");
const categoryFilter = document.getElementById("category-filter");
const priceSort = document.getElementById("price-sort");
const searchBar = document.getElementById("search-bar");
const themeToggle = document.getElementById("theme-toggle");
const cartButton = document.getElementById("cart-button");
const cartCount = document.getElementById("cart-count");
const loadingSpinner = document.getElementById("loading-spinner");
const checkoutPopup = document.getElementById("checkout-popup");
const cartItems = document.getElementById("cart-items");
const closePopup = document.getElementById("close-popup");
const homeLink = document.getElementById("home-link");
const playButton = document.getElementById("play-button");

// State for Filtered Products
let filteredProducts = [...products];


// Render Products
function renderProducts(products) {
    productList.innerHTML = products.map(product => `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}" loading="lazy">
            <h3>${product.name}</h3>
            <p>${formatPrice(product.price)}</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
    `).join("");
}


// Add to Cart with Animation
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    cartCount.textContent = cart.length;

    // Animation: Move product to cart
    const button = document.querySelector(`button[onclick="addToCart(${productId})"]`);
    button.classList.add("animate-to-cart");
    setTimeout(() => button.classList.remove("animate-to-cart"), 1000);
}

// Show Checkout Popup
cartButton.addEventListener("click", () => {
    cartItems.innerHTML = cart.map(item => `
        <li>${item.name} - ${formatPrice(item.price)}</li>
    `).join("");
    checkoutPopup.style.display = "flex";
});

// Close Checkout Popup
closePopup.addEventListener("click", () => {
    checkoutPopup.style.display = "none";
});

// Filter by Category
categoryFilter.addEventListener("change", () => {
    const category = categoryFilter.value;
    filteredProducts = category === "all" ? products : products.filter(p => p.category === category);
    renderProducts(filteredProducts);
});

// Sort by Price
priceSort.addEventListener("change", () => {
    const sortBy = priceSort.value;
    let sortedProducts = [...filteredProducts]; // Sort the filtered products
    if (sortBy === "low-high") {
        sortedProducts.sort((a, b) => a.price - b.price);
    } else if (sortBy === "high-low") {
        sortedProducts.sort((a, b) => b.price - a.price);
    }
    renderProducts(sortedProducts);
});

// Search Products
searchBar.addEventListener("input", () => {
    const query = searchBar.value.toLowerCase();
    filteredProducts = products.filter(p => p.name.toLowerCase().includes(query));
    renderProducts(filteredProducts);
});

// Toggle Dark Theme
themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark-theme");
});


// Music Files
const musicFiles = [
    "assets/music/2.aac",
    "assets/music/3.aac",
    "assets/music/4,aac",
    "assets/music/5.aac"
];
let currentMusicIndex = 0;

// Play Music with Animation and Cycle Through Tracks
playButton.addEventListener("click", () => {
    const musicPlayer = document.getElementById("music-player");

    // Set the current music file
    musicPlayer.src = musicFiles[currentMusicIndex];

    // Play the music
    musicPlayer.play();

    // Add soothing animation
    playButton.classList.add("play-animation");
    setTimeout(() => playButton.classList.remove("play-animation"), 2000); // Animation lasts 2 seconds

    // Cycle to the next music track
    currentMusicIndex = (currentMusicIndex + 1) % musicFiles.length;
});


// Refresh Home Page
homeLink.addEventListener("click", (e) => {
    e.preventDefault();
    filteredProducts = [...products]; // Reset filtered products
    renderProducts(filteredProducts);
});

// Initial Load
renderProducts(filteredProducts);