document.addEventListener('DOMContentLoaded', loadTasks);
document.getElementById('todo-form').addEventListener('submit', addTask);

function addTask(event) {
  event.preventDefault();
  const taskInput = document.getElementById('task-input');
  const dateTimeInput = document.getElementById('date-time-input');
  const taskText = taskInput.value;
  const dateTime = dateTimeInput.value;

  const taskItem = document.createElement('li');

  const taskDetails = document.createElement('div');
  taskDetails.className = 'task-details';

  const taskName = document.createElement('span');
  taskName.textContent = taskText;
  
  const taskDateTime = document.createElement('span');
  taskDateTime.textContent = `Due: ${new Date(dateTime).toLocaleString()}`;

  taskDetails.appendChild(taskName);
  taskDetails.appendChild(taskDateTime);

  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'Delete';
  deleteButton.addEventListener('click', deleteTask);

  taskItem.appendChild(taskDetails);
  taskItem.appendChild(deleteButton);

  document.getElementById('task-list').appendChild(taskItem);
  
  saveTask(taskText, dateTime);
  taskInput.value = '';
  dateTimeInput.value = '';
}

function deleteTask(event) {
  const taskItem = event.target.parentElement;
  const taskText = taskItem.querySelector('.task-details span').textContent;
  taskItem.remove();
  
  removeTask(taskText);
}

function saveTask(task, dateTime) {
  let tasks = localStorage.getItem('tasks');
  if (!tasks) {
    tasks = [];
  } else {
    tasks = JSON.parse(tasks);
  }
  tasks.push({ task, dateTime });
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function removeTask(task) {
  let tasks = JSON.parse(localStorage.getItem('tasks'));
  tasks = tasks.filter(t => t.task !== task);
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function loadTasks() {
  let tasks = localStorage.getItem('tasks');
  if (!tasks) {
    tasks = [];
  } else {
    tasks = JSON.parse(tasks);
  }
  
  tasks.forEach(task => {
    const taskItem = document.createElement('li');

    const taskDetails = document.createElement('div');
    taskDetails.className = 'task-details';

    const taskName = document.createElement('span');
    taskName.textContent = task.task;

    const taskDateTime = document.createElement('span');
    taskDateTime.textContent = `Due: ${new Date(task.dateTime).toLocaleString()}`;

    taskDetails.appendChild(taskName);
    taskDetails.appendChild(taskDateTime);

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', deleteTask);

    taskItem.appendChild(taskDetails);
    taskItem.appendChild(deleteButton);

    document.getElementById('task-list').appendChild(taskItem);
  });
}
