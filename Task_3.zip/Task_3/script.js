async function fetchQuiz() {
    try {
        const res = await fetch("https://opentdb.com/api.php?amount=1&type=multiple");
        const data = await res.json();
        const questionData = data.results[0];

        const questionText = questionData.question;
        const correctAnswer = questionData.correct_answer;
        const allAnswers = [...questionData.incorrect_answers, correctAnswer].sort(() => Math.random() - 0.5);

        document.getElementById("question").innerHTML = questionText;
        document.querySelectorAll(".quiz-btn").forEach((btn, i) => {
            btn.innerText = allAnswers[i];
            btn.onclick = () => checkAnswer(allAnswers[i], correctAnswer);
        });

    } catch (error) {
        console.error("Error fetching quiz:", error);
    }
}

let score = 0;

function checkAnswer(selected, correct) {
    if (selected === correct) {
        score += 10;
        document.getElementById("result").innerText = "✅ Correct!";
    } else {
        document.getElementById("result").innerText = "❌ Wrong!";
    }
    document.getElementById("score").innerText = score;
    setTimeout(fetchQuiz, 2000); 
}

fetchQuiz();

const images = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg"]; 
const carousel = document.getElementById("carousel-image");
let index = 0;

function showImage(i) {
    carousel.src = `images/${images[i]}`;
}

document.getElementById("prev").addEventListener("click", () => {
    index = (index - 1 + images.length) % images.length;
    showImage(index);
});

document.getElementById("next").addEventListener("click", () => {
    index = (index + 1) % images.length;
    showImage(index);
});

showImage(index);


function fetchJoke() {
    fetch("https://v2.jokeapi.dev/joke/Any?type=single")
        .then(response => response.json())
        .then(data => {
            document.getElementById("joke").textContent = data.joke;
        })
        .catch(error => {
            console.error("Error fetching joke:", error);
            document.getElementById("joke").textContent = "Failed to load joke.";
        });
}

fetchJoke(); 
setInterval(fetchJoke, 4000);
